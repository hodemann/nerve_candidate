Font that was used:
https://www.dafont.com/viking-squad.font